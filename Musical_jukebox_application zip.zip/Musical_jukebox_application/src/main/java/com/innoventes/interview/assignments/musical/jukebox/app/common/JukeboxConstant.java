package com.innoventes.interview.assignments.musical.jukebox.app.common;

public final class JukeboxConstant {
	
	
	public static final String MSG_NO_PLAYLIST_FOUND = "No PlayList Found with Name ";

    private  JukeboxConstant() {
    }

}




